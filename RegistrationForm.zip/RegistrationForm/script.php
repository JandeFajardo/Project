<?php 

$connection = mysqli_connect("localhost", "root", "", "registration_db");

    if (isset($_POST['submit'])) {
         $username = mysqli_escape_string($connection,$_POST['username']);
         $password = mysqli_escape_string($connection,$_POST['password']);
    if ($username!="" && $password !="") {
         $sql = "SELECT userId FROM login WHERE username='$username' and password='$password'";
         $result = mysqli_query($connection ,$sql);
         $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
                  $_SESSION['valid'] = true;
                  $_SESSION['timeout'] = time();
                  $_SESSION['username'] = '$username';
                    echo '<script language="javascript">';
                    echo 'alert("Username or password is invalid")';
                    echo '</script>';
        
         $count = mysqli_num_rows($result);
     if ($count==1) {
         header("location:new_account.php");
  }
}

}
?> 