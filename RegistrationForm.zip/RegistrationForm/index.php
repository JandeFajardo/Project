<?php include 'script.php';
$connection = mysqli_connect("localhost", "root", "", "registration_db");

    if (isset($_POST['submit'])) {
         $username = mysqli_escape_string($connection,$_POST['username']);
         $password = mysqli_escape_string($connection,$_POST['password']);
    if ($username!="" && $password !="") {
         $sql = "SELECT userId FROM login WHERE username='$username' and password='$password'";
         $result = mysqli_query($connection ,$sql);
         $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
                  $_SESSION['valid'] = true;
                  $_SESSION['timeout'] = time();
                  $_SESSION['username'] = '$username';
                    echo '<script language="javascript">';
                    echo 'alert("Username or password is invalid")';
                    echo '</script>';
        
         $count = mysqli_num_rows($result);
     if ($count==1) {
         header("location:new_account.php");
  }
}

}
?> 

<!DOCTYPE html>
<html>
<head>
  <title>Log in</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
 
</head>
<body id="indexphp">

<section id="cover">
    <div id="cover-caption">
        <div id="container" class="container">
            <div class="row">
                <div class="log col-sm-6 offset-sm-3 col">
                    <h4 class="text-center">Log in</h4>
                    <div class="info-form">
                        <form method="post" action="main.php" class="form-inlin justify-content-center">
                            <div class="form-group">
                                <input type="text" class="form-control" name="username" placeholder="Username">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="password" placeholder="Password">
                            </div>
                            <div class="row d-flex justify-content-around">
                            <div class="pull-left"><button type="submit" name="submit" class="btn btn-secondary btn-outline-light">Login</button></div>
                            <div class="pull-right"><button class="btn btn-secondary btn-outline-light" formaction="new_account.php">Create account</button></div>
                            </div>
                        </form>
                    </div>
                    <br>
                </div>
            </div>
        </div>
    </div>
</section>





</body>
</html>